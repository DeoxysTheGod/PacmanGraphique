var searchData=
[
  ['bgtext_449',['BgText',['../class_bg_text.html',1,'']]]
];

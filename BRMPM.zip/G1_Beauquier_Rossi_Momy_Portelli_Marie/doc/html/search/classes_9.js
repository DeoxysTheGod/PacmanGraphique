var searchData=
[
  ['sghost_467',['sGhost',['../structs_ghost.html',1,'']]],
  ['shape_468',['Shape',['../classns_shape_1_1_shape.html',1,'nsShape']]],
  ['spacman_469',['sPacman',['../structs_pacman.html',1,'']]],
  ['sprite_470',['Sprite',['../classns_gui_1_1_sprite.html',1,'nsGui']]]
];
